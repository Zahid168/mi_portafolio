package Global;

import java.util.ArrayList;

import POJO.Evento;

public class Info {
    public static final ArrayList<Evento> lista = new ArrayList<>();
    public static final ArrayList<Evento> listaBajas = new ArrayList<>();
}
