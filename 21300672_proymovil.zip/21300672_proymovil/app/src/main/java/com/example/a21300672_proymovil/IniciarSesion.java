package com.example.a21300672_proymovil;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class IniciarSesion extends AppCompatActivity {

    EditText usuario, contrasena;
    Button iniciarSesion;
    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sesion);

        usuario = findViewById(R.id.editText_Usuario);
        contrasena = findViewById(R.id.editText_Contrasena);
        iniciarSesion = findViewById(R.id.button_IniciarSesion);

        iniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickIniciarSesion();
            }
        });

        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        if(archivo.contains("id_usuario")){
            Intent ini = new Intent(this, MainActivity.class);
            startActivity(ini);
            finish();
        }
    }

    private void onClickIniciarSesion() {

        String url = "http://192.168.1.233/bdIntegrador/ingreso.php?usr="
                + usuario.getText().toString()
                + "&pass="
                + contrasena.getText().toString();

        JsonObjectRequest pet = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    if (response.getInt("usr") != -1){
                        Intent i = new Intent(IniciarSesion.this, MainActivity.class);
                        SharedPreferences.Editor editor = archivo.edit();
                        editor.putInt("id_usuario", response.getInt("usr"));
                        editor.commit();
                        startActivity(i);
                        finish();
                    } else {
                        usuario.setText("");
                        contrasena.setText("");
                    }
                } catch (JSONException e){
                    throw new RuntimeException(e);
                }
                Toast.makeText(IniciarSesion.this, response.toString(), Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("yo", error.getMessage());
            }
        }
        );
        RequestQueue lanzarPeticion = Volley.newRequestQueue(this);
        lanzarPeticion.add(pet);
    }
}