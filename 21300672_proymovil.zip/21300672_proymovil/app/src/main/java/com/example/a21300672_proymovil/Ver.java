package com.example.a21300672_proymovil;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import Adaptadores.AdaptadorVer;

public class Ver extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView recycler;
    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        recycler = findViewById(R.id.RecyclerView_Ver);

        AdaptadorVer adaptador = new AdaptadorVer();
        adaptador.context=this;
        LinearLayoutManager llm = new LinearLayoutManager
                (this,LinearLayoutManager.VERTICAL,false);
        recycler.setAdapter(adaptador);
        recycler.setLayoutManager(llm);
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.opcionVer) {
            Toast.makeText(this, "Ya te encuentras en esa actividad.", Toast.LENGTH_SHORT).show();
        }
        if (item.getItemId() == R.id.opcionRegistro) {
            Intent objeto = new Intent(this, MainActivity.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionModificar) {
            Intent objeto = new Intent(this, Modificar.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionEliminar) {
            Intent objeto = new Intent(this, Eliminar.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionSalir){

            //Con BD
            SharedPreferences.Editor editor = archivo.edit();
            editor.remove("id_usuario");
            editor.commit();
            Intent x = new Intent(this, IniciarSesion.class);
            startActivity(x);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}