package com.example.a21300672_proymovil;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import Global.Info;

public class Card extends AppCompatActivity {

    TextView Nombre, Registro, Fecha, HoraInicio, HoraFin, Telefono, Laboratorio, Material, Cantidad, Maestro;
    Button llamar;
    int posicion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        Nombre = findViewById(R.id.textView_Nombre);
        Registro = findViewById(R.id.textView_Registro);
        Fecha = findViewById(R.id.textView_Fecha);
        HoraInicio = findViewById(R.id.textView_HoraInicio);
        HoraFin = findViewById(R.id.textView_HoraFin);
        Telefono = findViewById(R.id.textView_Telefono);
        Laboratorio = findViewById(R.id.textView_Laboratorio);
        Material = findViewById(R.id.textView_Material);
        Cantidad = findViewById(R.id.textView_Cantidad);
        Maestro = findViewById(R.id.textView_Maestro);

        llamar = findViewById(R.id.button_Llamar);
        llamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickLlamar();
            }
        });

        posicion = getIntent().getIntExtra("pos", -1);
        Nombre.setText(Info.lista.get(posicion).getNombre());
        Registro.setText(Info.lista.get(posicion).getRegistro());
        Fecha.setText(Info.lista.get(posicion).getFecha());
        HoraInicio.setText(Info.lista.get(posicion).getHoraInicio());
        HoraFin.setText(Info.lista.get(posicion).getHoraFin());
        Telefono.setText(Info.lista.get(posicion).getTelefono());
        Laboratorio.setText(Info.lista.get(posicion).getLaboratorio());
        Material.setText(Info.lista.get(posicion).getMaterial());
        Cantidad.setText(Info.lista.get(posicion).getCantidad());
        Cantidad.setText(Info.lista.get(posicion).getMaestro());

    }

    private void onClickLlamar() {
        Intent llamar = new Intent(Intent.ACTION_DIAL);
        llamar.setData(Uri.parse("tel:" + Telefono.getText().toString()));
        if (ActivityCompat.checkSelfPermission
                (this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.CALL_PHONE}, 10);
            return;
        }
        startActivity(llamar);
    }
}