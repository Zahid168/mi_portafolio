package com.example.a21300672_proymovil;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import Global.Info;
import POJO.Evento;

public class MainActivity extends AppCompatActivity {
    EditText Nombre, Registro, Fecha, HoraInicio, HoraFin, Telefono, Laboratorio, Cantidad, Maestro;
    Spinner Material;
    String[] opcionesMaterial = {"Cautin", "Multimetro", "Osciloscopio", "Generador de senal"};
    int posicionMaterial = 0;
    String opcionSeleccionada = null;
    Button Agregar;
    Toolbar toolbar;
    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Nombre = findViewById(R.id.editText_Nombre);
        Registro = findViewById(R.id.editText_Registro);
        Fecha = findViewById(R.id.editText_Fecha);
        HoraInicio = findViewById(R.id.editText_HoraInicio);
        HoraFin = findViewById(R.id.editText_HoraFin);
        Telefono = findViewById(R.id.editText_Telefono);
        Laboratorio = findViewById(R.id.editText_Laboratorio);
        Material = findViewById(R.id.spinner_Material);
        Cantidad = findViewById(R.id.editText_Cantidad);
        Maestro = findViewById(R.id.editText_Maestro);

        Fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickFecha();
            }
        });
        HoraInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickHoraInicio();
            }
        });
        HoraFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickHoraFin();
            }
        });

        ArrayAdapter<String> adaptador = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesMaterial);
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Material.setAdapter(adaptador);
        Material.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                opcionSeleccionada = opcionesMaterial[position];
                posicionMaterial = position;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                opcionSeleccionada = null;

            }
        });

        Agregar = findViewById(R.id.button_Agregar);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        recuperarDatos();
    }

    private void onClickHoraInicio() {
        int hora, minuto;
        Calendar actual = Calendar.getInstance();
        hora = actual.get(Calendar.HOUR_OF_DAY);
        minuto = actual.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String cadena;
                cadena = "" + hourOfDay + ":" + minute + ":00";
                HoraInicio.setText(cadena);
            }
        }, hora, minuto, true);
        tpd.show();
    }
    private void onClickHoraFin() {
        int hora, minuto;
        Calendar actual = Calendar.getInstance();
        hora = actual.get(Calendar.HOUR_OF_DAY);
        minuto = actual.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String cadena;
                cadena = "" + hourOfDay + ":" + minute + ":00";
                HoraFin.setText(cadena);
            }
        }, hora, minuto, true);
        tpd.show();
    }

    private void onClickFecha() {
        int dia, mes, anno;
        Calendar actual = Calendar.getInstance();
        dia = actual.get(Calendar.DAY_OF_MONTH);
        mes = actual.get(Calendar.MONTH);
        anno = actual.get(Calendar.YEAR);
        DatePickerDialog datPd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String cadena;
                cadena = "" + year + "-" + (month + 1) + "-" + dayOfMonth;
                Fecha.setText(cadena);
            }
        }, anno, mes, dia);
        datPd.show();
    }

    public void BotonAgregar(View view) {
        if(Nombre.getText().toString().isEmpty() ||
                Registro.getText().toString().isEmpty() ||
                Fecha.getText().toString().isEmpty() ||
                HoraInicio.getText().toString().isEmpty() ||
                HoraFin.getText().toString().isEmpty() ||
                Telefono.getText().toString().isEmpty() ||
                Laboratorio.getText().toString().isEmpty() ||
                Cantidad.getText().toString().isEmpty() ||
                Maestro.getText().toString().isEmpty() ||
                opcionSeleccionada == null
        )
        {
            Toast.makeText(this, "Todos los elementos deben estar llenos para agregar un dato.", Toast.LENGTH_LONG).show();
        }else {
            Evento vale = new Evento();
            vale.setNombre(Nombre.getText().toString());
            vale.setRegistro(Registro.getText().toString());
            vale.setFecha(Fecha.getText().toString());
            vale.setHoraInicio(HoraInicio.getText().toString());
            vale.setHoraFin(HoraFin.getText().toString());
            vale.setTelefono(Telefono.getText().toString());
            vale.setLaboratorio(Laboratorio.getText().toString());
            vale.setCantidad(Cantidad.getText().toString());
            vale.setMaestro(Maestro.getText().toString());
            vale.setMaterial(opcionSeleccionada);
            vale.setPosicionInvitaciones(posicionMaterial);

            Info.lista.add(vale);

            RequestQueue solicitud = Volley.newRequestQueue(this);
            StringRequest sql = new StringRequest(
                    Request.Method.POST, "http://192.168.1.233/bdIntegrador/agregar.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String s) {
                            /*Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
                            Log.d("no paso", s);*/
                            try {
                                JSONObject jsonResponse = new JSONObject(s);
                                if (jsonResponse.has("id")) {
                                    int id = jsonResponse.getInt("id");
                                    vale.setId(id);

                                    Toast.makeText(MainActivity.this, "Registro insertado con ID: " + id, Toast.LENGTH_SHORT).show();
                                } else if (jsonResponse.has("error")) {
                                    String error = jsonResponse.getString("error");
                                    Toast.makeText(MainActivity.this, jsonResponse.getString("error"), Toast.LENGTH_SHORT).show();
                                    Log.d("Server error", error);

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(MainActivity.this, "Error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                                Log.e("JSONException", e.getMessage()); // Registro de la excepción JSON
                                Log.d("Server Response", s);
                            }
                        }
                    },
                new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Toast.makeText(MainActivity.this, volleyError.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d("no paso", volleyError.getMessage());
                }
            }
            ){
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> x = new HashMap<>();
                    x.put("Nombre", "" + vale.getNombre());
                    x.put("Edad", "" + vale.getRegistro());
                    x.put("Fecha", "" + vale.getFecha());
                    x.put("HoraInicio", "" + vale.getHoraInicio());
                    x.put("HoraFin", "" + vale.getHoraFin());
                    x.put("Telefono", "" + vale.getTelefono());
                    x.put("Precio", "" + vale.getLaboratorio());
                    x.put("Invitados", "" + vale.getCantidad());
                    x.put("Servicios", "" + vale.getMaestro());
                    x.put("TipoInvitaciones", "" + vale.getPosicionInvitaciones());
                    return x;
                }
            };
            solicitud.add(sql);

            Toast.makeText(this, "Se ha agregado un elemento a la lista.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.opcionVer) {
            Intent objeto = new Intent(this, Ver.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionRegistro) {
            Toast.makeText(this, "Ya te encuentras en esa actividad.", Toast.LENGTH_SHORT).show();
        }
        if (item.getItemId() == R.id.opcionModificar) {
            Intent objeto = new Intent(this, Modificar.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionEliminar) {
            Intent objeto = new Intent(this, Eliminar.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionSalir){
            SharedPreferences.Editor editor = archivo.edit();
            editor.remove("id_usuario");
            editor.commit();
            Intent x = new Intent(this, IniciarSesion.class);
            startActivity(x);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void recuperarDatos(){
        String url = "http://192.168.1.233/bdIntegrador/registrarDatos.php";

        RequestQueue solicitud = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray jsonArray) {

                Info.lista.clear();
                for (int i = 0; i < jsonArray.length(); i++){
                    try {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        // Parsear los campos del JSON
                        String nombre = jsonObject.getString("nombre");
                        String registro = jsonObject.getString("registro");
                        String fecha = jsonObject.getString("fecha");
                        String horaInicio = jsonObject.getString("horaInicio");
                        String horaFin = jsonObject.getString("horaFinal");
                        String telefono = jsonObject.getString("telefono");
                        String laboratorio = jsonObject.getString("laboratorio");
                        int material = jsonObject.getInt("material");
                        String cantidad = jsonObject.getString("cantidad");
                        String maestro = jsonObject.getString("maestro");
                        int id = jsonObject.getInt("id");

                        Evento evento = new Evento();
                        evento.setNombre(nombre);
                        evento.setRegistro(registro);
                        evento.setFecha(fecha);
                        evento.setHoraInicio(horaInicio);
                        evento.setHoraFin(horaFin);
                        evento.setTelefono(telefono);
                        evento.setLaboratorio(laboratorio);
                        evento.setPosicionInvitaciones(material);
                        evento.setMaterial(opcionesMaterial[material]);
                        evento.setCantidad(cantidad);
                        evento.setMaestro(maestro);
                        evento.setId(id);

                        Info.lista.add(evento);
                    } catch (JSONException e) {
                        Log.e("recuperarDatos", "Error parsing JSON: " + e.getMessage());
                    }
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "no jalo  :(", Toast.LENGTH_SHORT).show();
                Log.d("recuperarDatos", error.getMessage());
            }
        });
        solicitud.add(jsonArrayRequest);

    }
}