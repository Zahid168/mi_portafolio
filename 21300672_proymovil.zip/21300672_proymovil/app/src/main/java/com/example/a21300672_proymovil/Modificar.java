package com.example.a21300672_proymovil;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import Global.Info;
import POJO.Evento;

public class Modificar extends AppCompatActivity {

    EditText Nombre, Registro, Fecha, HoraInicio, HoraFin, Telefono, Laboratorio, Cantidad, Maestro;
    Spinner Material;
    String[] opcionesMaterial = {"Cautin", "Multimetro", "Osciloscopio", "Generador de senal"};
    int posicionInvitaiciones = 0;
    String opcionSeleccionada = null;
    Button BotonAnterior, BotonSiguiente, BotonGuardar;
    int posicion;
    Toolbar toolbar;
    SharedPreferences archivo;
    Evento unEvento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);

        Nombre = findViewById(R.id.editText_Nombre);
        Registro = findViewById(R.id.editText_Registro);
        Fecha = findViewById(R.id.editText_Fecha);
        HoraInicio = findViewById(R.id.editText_HoraInicio);
        HoraFin = findViewById(R.id.editText_HoraFin);
        Telefono = findViewById(R.id.editText_Telefono);
        Laboratorio = findViewById(R.id.editText_Laboratorio);
        Material = findViewById(R.id.spinner_Material);
        Cantidad = findViewById(R.id.editText_Cantidad);
        Maestro = findViewById(R.id.editText_Maestro);

        Fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickFecha();
            }
        });
        HoraInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickHoraInicio();
            }
        });
        HoraFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickHoraFin();
            }
        });

        Material = findViewById(R.id.spinner_Invitaciones);
        ArrayAdapter<String> adaptador = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesMaterial);
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Material.setAdapter(adaptador);
        Material.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                opcionSeleccionada = opcionesMaterial[position];
                posicionInvitaiciones = position;
                // Usa el valor de 'opcionSeleccionada' como necesites
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                opcionSeleccionada = null;
                // Maneja el caso donde no se selecciona ninguna opción
            }
        });

        BotonAnterior = findViewById(R.id.button_Anterior);
        BotonSiguiente = findViewById(R.id.button_Siguiente);
        BotonGuardar = findViewById(R.id.button_Guardar);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        posicion = 0;
        if (Info.lista.size() > 0) {
            unEvento = Info.lista.get(0);
            imprime(unEvento);
        }
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
    }

    private void imprime(Evento x) {
        Nombre.setText(x.getNombre());
        Registro.setText(x.getRegistro());
        Fecha.setText(x.getFecha());
        HoraInicio.setText(x.getHoraInicio());
        HoraFin.setText(x.getHoraFin());
        Telefono.setText(x.getTelefono());
        Laboratorio.setText(x.getLaboratorio());
        Cantidad.setText(x.getCantidad());
        Maestro.setText(x.getMaestro());
        Material.setSelection(x.getPosicionInvitaciones());
    }

    private void onClickHoraInicio() {
        int hora, minuto;
        Calendar actual = Calendar.getInstance();
        hora = actual.get(Calendar.HOUR_OF_DAY);
        minuto = actual.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String cadena;
                cadena = "" + hourOfDay + ":" + minute + ":00";
                HoraInicio.setText(cadena);
            }
        }, hora, minuto, true);
        tpd.show();
    }
    private void onClickHoraFin() {
        int hora, minuto;
        Calendar actual = Calendar.getInstance();
        hora = actual.get(Calendar.HOUR_OF_DAY);
        minuto = actual.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String cadena;
                cadena = "" + hourOfDay + ":" + minute + ":00";
                HoraFin.setText(cadena);
            }
        }, hora, minuto, true);
        tpd.show();
    }

    private void onClickFecha() {
        int dia, mes, anno;
        Calendar actual = Calendar.getInstance();
        dia = actual.get(Calendar.DAY_OF_MONTH);
        mes = actual.get(Calendar.MONTH);
        anno = actual.get(Calendar.YEAR);
        DatePickerDialog datPd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String cadena;
                cadena = "" + year + "-" + (month + 1) + "-" + dayOfMonth;
                Fecha.setText(cadena);
            }
        }, anno, mes, dia);
        datPd.show();
    }

    public void BotonAnterior(View view) {
        if(Info.lista.size() > 0){
            if (posicion == 0)
                posicion = Info.lista.size() - 1;
            else
                posicion = posicion - 1;
            unEvento = Info.lista.get(posicion);
            imprime(unEvento);
        }
    }
    public void BotonSiguiente(View view) {
        if(Info.lista.size() > 0){
            if (posicion ==Info.lista.size() - 1)
                posicion = 0;
            else
                posicion++;
            unEvento = Info.lista.get(posicion);
            imprime(unEvento);
        }
    }
    public void BotonGuardar(View view) {
        if (Info.lista.size() > 0){
            if(Nombre.getText().toString().isEmpty() ||
                    Registro.getText().toString().isEmpty() ||
                    Fecha.getText().toString().isEmpty() ||
                    HoraInicio.getText().toString().isEmpty() ||
                    HoraFin.getText().toString().isEmpty() ||
                    Telefono.getText().toString().isEmpty() ||
                    Laboratorio.getText().toString().isEmpty() ||
                    Cantidad.getText().toString().isEmpty() ||
                    Maestro.getText().toString().isEmpty() ||
                    opcionSeleccionada == null){
                Toast.makeText(this, "Todos los elementos deben estar llenos para modificar un dato.", Toast.LENGTH_LONG).show();
            }else {
                unEvento.setNombre(Nombre.getText().toString());
                unEvento.setRegistro(Registro.getText().toString());
                unEvento.setFecha(Fecha.getText().toString());
                unEvento.setHoraInicio(HoraInicio.getText().toString());
                unEvento.setHoraFin(HoraFin.getText().toString());
                unEvento.setTelefono(Telefono.getText().toString());
                unEvento.setLaboratorio(Laboratorio.getText().toString());
                unEvento.setCantidad(Cantidad.getText().toString());
                unEvento.setMaestro(Maestro.getText().toString());
                unEvento.setMaterial(opcionSeleccionada);
                unEvento.setPosicionInvitaciones(posicionInvitaiciones);

                // Actualizar en la base de datos
                RequestQueue solicitud = Volley.newRequestQueue(this);
                StringRequest sql = new StringRequest(
                        Request.Method.POST, "http://192.168.1.233/bdIntegrador/modificar.php",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jsonResponse = new JSONObject(response);
                                    if (jsonResponse.has("id")) {
                                        int id = jsonResponse.getInt("id");
                                        // Aquí puedes registrar el ID junto con un mensaje relevante
                                        Log.d("Modificación exitosa", "Se modificó el registro con ID: " + id);
                                    } else if (jsonResponse.has("error")) {
                                        String error = jsonResponse.getString("error");
                                        Toast.makeText(Modificar.this, error, Toast.LENGTH_SHORT).show();
                                        Log.e("Error de modificación", error);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Log.e("JSONException", e.getMessage());
                                    Log.d("Respuesta del servidor", response); // Log de la respuesta completa del servidor
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Modificar.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        Log.d("Modificar", error.getMessage());
                    }
                }
                ) {
                    @Nullable
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("id", String.valueOf(unEvento.getId()));
                        params.put("Nombre", unEvento.getNombre());
                        params.put("Edad", unEvento.getRegistro());
                        params.put("Fecha", unEvento.getFecha());
                        params.put("HoraInicio", unEvento.getHoraInicio());
                        params.put("HoraFin", unEvento.getHoraFin());
                        params.put("Telefono", unEvento.getTelefono());
                        params.put("Laboratorio", unEvento.getLaboratorio());
                        params.put("Cantidad", unEvento.getCantidad());
                        params.put("Maestro", unEvento.getMaestro());
                        params.put("Material", String.valueOf(unEvento.getPosicionInvitaciones()));

                        return params;
                    }
                };
                solicitud.add(sql);


                Toast.makeText(this, "El dato fue modificado exitosamente", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.opcionVer) {
            Intent objeto = new Intent(this, Ver.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionRegistro) {
            Intent objeto = new Intent(this, MainActivity.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionModificar) {
            Toast.makeText(this, "Ya te encuentras en esa actividad.", Toast.LENGTH_SHORT).show();
        }
        if (item.getItemId() == R.id.opcionEliminar) {
            Intent objeto = new Intent(this, Eliminar.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionSalir){
            SharedPreferences.Editor editor = archivo.edit();
            editor.remove("id_usuario");
            editor.commit();
            Intent x = new Intent(this, IniciarSesion.class);
            startActivity(x);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}