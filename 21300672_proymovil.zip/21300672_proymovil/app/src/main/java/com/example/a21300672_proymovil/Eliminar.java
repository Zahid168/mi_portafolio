package com.example.a21300672_proymovil;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

import Adaptadores.AdaptadorEliminar;
import Global.Info;
import POJO.Evento;

public class Eliminar extends AppCompatActivity {

    Button botonEliminar;
    RecyclerView recycler;
    Toolbar toolbar;
    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar);

        botonEliminar = findViewById(R.id.button_Eliminar);
        recycler = findViewById(R.id.RecyclerView_Eliminar);

        AdaptadorEliminar ae = new AdaptadorEliminar();
        ae.context = this;
        LinearLayoutManager llm = new LinearLayoutManager
                (this, LinearLayoutManager.VERTICAL, false);
        recycler.setAdapter(ae);
        recycler.setLayoutManager(llm);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminar();
            }
        });

        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
    }



    private void eliminar() {
        for (int i = 0; i < Info.listaBajas.size(); i++) {
            Evento unEvento = Info.listaBajas.get(i);

            RequestQueue solicitud = Volley.newRequestQueue(this);
            StringRequest sql = new StringRequest(
                    Request.Method.POST, "http://192.168.1.233/bdIntegrador/eliminar.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String s) {
                            Toast.makeText(Eliminar.this, s, Toast.LENGTH_SHORT).show();
                            Log.d("no paso", s);

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError volleyError) {
                            Toast.makeText(Eliminar.this, volleyError.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.d("no paso", volleyError.getMessage());
                        }
                    }
            ){
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> x = new HashMap<>();
                    x.put("id", String.valueOf(unEvento.getId()));
                    return x;
                }
            };
            solicitud.add(sql);

            Info.lista.remove(unEvento);
        }
        Info.listaBajas.clear();
        recycler.getAdapter().notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.opcionVer) {
            Intent objeto = new Intent(this, Ver.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionRegistro) {
            Intent objeto = new Intent(this, MainActivity.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionModificar) {
            Intent objeto = new Intent(this, Modificar.class);
            startActivity(objeto);
        }
        if (item.getItemId() == R.id.opcionEliminar) {
            Toast.makeText(this, "Ya te encuentras en esa actividad.", Toast.LENGTH_SHORT).show();
        }
        if (item.getItemId() == R.id.opcionSalir){

            SharedPreferences.Editor editor = archivo.edit();
            editor.remove("id_usuario");
            editor.commit();
            Intent x = new Intent(this, IniciarSesion.class);
            startActivity(x);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}