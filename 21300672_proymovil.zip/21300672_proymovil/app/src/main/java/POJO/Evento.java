package POJO;

public class Evento {
    String Nombre;
    String Registro;
    String Fecha;
    String HoraInicio;
    String HoraFin;
    String Telefono;
    String Laboratorio;
    String Material;
    String Cantidad;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getRegistro() {
        return Registro;
    }

    public void setRegistro(String registro) {
        Registro = registro;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getHoraInicio() {
        return HoraInicio;
    }

    public void setHoraInicio(String horaInicio) {
        HoraInicio = horaInicio;
    }

    public String getHoraFin() {
        return HoraFin;
    }

    public void setHoraFin(String horaFin) {
        HoraFin = horaFin;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getLaboratorio() {
        return Laboratorio;
    }

    public void setLaboratorio(String laboratorio) {
        Laboratorio = laboratorio;
    }

    public String getMaterial() {
        return Material;
    }

    public void setMaterial(String material) {
        Material = material;
    }

    public String getCantidad() {
        return Cantidad;
    }

    public void setCantidad(String cantidad) {
        Cantidad = cantidad;
    }

    public String getMaestro() {
        return Maestro;
    }

    public void setMaestro(String maestro) {
        Maestro = maestro;
    }

    String Maestro;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    int Id;

    public int getPosicionInvitaciones() {
        return PosicionInvitaciones;
    }

    public void setPosicionInvitaciones(int posicionInvitaciones) {
        PosicionInvitaciones = posicionInvitaciones;
    }

    int PosicionInvitaciones;

   }