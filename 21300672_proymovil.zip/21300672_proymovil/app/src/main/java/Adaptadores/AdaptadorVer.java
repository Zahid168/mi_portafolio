package Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a21300672_proymovil.Card;
import com.example.a21300672_proymovil.R;

import Global.Info;

public class AdaptadorVer extends RecyclerView.Adapter<AdaptadorVer.MiActivity> {
    public Context context;
    @NonNull
    @Override
    public MiActivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = View.inflate(context, R.layout.viewholder_ver, null);
        MiActivity obj = new MiActivity(v);
        return obj;
    }

    @Override
    public void onBindViewHolder(@NonNull MiActivity holder, int i) {
        final int pos = i;
        holder.nombre.setText(Info.lista.get(i).getNombre());
        holder.fecha.setText(Info.lista.get(i).getFecha());
        holder.nombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent card = new Intent(context, Card.class);
                card.putExtra("pos", pos);
                context.startActivity(card);
            }
        });
    }

    @Override
    public int getItemCount() {
        return Info.lista.size();
    }

    public class MiActivity extends RecyclerView.ViewHolder {
        TextView nombre;
        TextView fecha;
        public MiActivity(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.textView_NombreVer);
            fecha = itemView.findViewById(R.id.textView_FechaVer);
        }
    }
}
