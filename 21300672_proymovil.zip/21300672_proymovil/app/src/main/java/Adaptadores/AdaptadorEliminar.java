package Adaptadores;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a21300672_proymovil.R;

import Global.Info;

public class AdaptadorEliminar extends RecyclerView.Adapter<AdaptadorEliminar.Mbajas> {
    public Context context;
    @NonNull
    @Override
    public Mbajas onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = View.inflate(context, R.layout.viewholder_eliminar, null);
        return new Mbajas(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Mbajas holder, int i) {
        final int pos = i;
        holder.nombre.setText(Info.lista.get(i).getNombre());
        holder.registro.setText(Info.lista.get(i).getEdad());
        holder.seleccion.setChecked(false);
        holder.seleccion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(((CheckBox)view).isChecked())
                    Info.listaBajas.add(Info.lista.get(pos));
                else
                    Info.listaBajas.remove(Info.lista.get(pos));
            }
        });
    }

    @Override
    public int getItemCount() {
        return Info.lista.size();
    }

    public class Mbajas extends RecyclerView.ViewHolder {
        TextView nombre, registro;
        CheckBox seleccion;
        public Mbajas(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.textView_NombreEliminar);
            registro = itemView.findViewById(R.id.textView_RegistroEliminar);
            seleccion = itemView.findViewById(R.id.checkBox_Eliminar);
        }
    }
}
